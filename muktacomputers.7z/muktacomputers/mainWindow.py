"""
Author: Md El Hossain
Website: alzestors.tk
Project: Business Tool
"""

from PyQt5.QtWidgets import (QWidget, QLabel, QDesktopWidget, QApplication, QPushButton,
                             QVBoxLayout, QHBoxLayout, QComboBox, QLineEdit, QSpinBox,
                             QPushButton, QListWidget, QRadioButton)
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import Qt

from calculator import Calc

class MainWindow(QWidget):
    result = 0
    def __init__(self):
        super().__init__()
        self.cc = Calc()
        self.T = len(self.cc.sellItems)
        self.initUI()
        self.grids()
        self.show()

    def initUI(self):
        self.setGeometry(300,300,700,550)
        self.setFixedHeight(550)
        self.setFixedWidth(700)
        self.center()
        self.setWindowTitle('Mukta Computers')
        self.setWindowIcon(QIcon('img/icon.png'))

    def grids(self):
        #main layout Vartical
        self.mainLayout = QVBoxLayout(self)
        self.setLayout(self.mainLayout)
        #welcome msg
        self.mainLayout.addStretch(1)
        lbl = QLabel('<h1>Welcome to Mukta Computer Dashbord</h1>', self)
        sub = QHBoxLayout(self)
        sub.addStretch(1)
        sub.addWidget(lbl)
        sub.addStretch(1)
        self.mainLayout.addLayout(sub)
        
        #payment
        px = self.cc.payment
        TI = "<b>Total Income: </b>{0}<b> Personal Income: </b>{1}\
              <b> Masked Income: </b>{2}<b> Paid: </b>{3}<br/>\
              <b>Today's Income: </b>{4}<b> Today's Personal Income: </b>{6}\
              <b> Today's Masked Income: </b>{7}<br/><b>Remaning: </b>{5}"\
              .format(px[0],px[1],px[2],px[3],px[4],px[5],px[7],px[8])
        self.paymentLabel = QLabel('', self)
        
        #Memo Window Layout
        subH = QHBoxLayout(self)
        subV = QVBoxLayout(self)
        subV1 = QVBoxLayout(self) 
        subV2 = QVBoxLayout(self) 
        #item list
        lbl = QLabel('<b>Item Discription: </b>', self)
        subV1.addWidget(lbl)
        self.combo = QComboBox(self)
        self.combo.addItems(self.cc.sellItems)


        #price quto
        try:
            self.RPlbl = QLabel(str(self.cc.sellItemPrice[self.combo.currentText()])+' tk', self)
        except:
            self.RPlbl = QLabel('Add Items first', self)
            
        self.combo.currentIndexChanged.connect(self.comboOnChange)
        self.pricespbx = QSpinBox(self)
        try:
            self.pricespbx.setValue(self.cc.sellItemPrice[self.combo.currentText()])
        except:
            self.pricespbx.setValue(0)
        self.pricespbx.setMaximum(10000)
        
        #item list
        subV2.addWidget(self.combo)
        
        #price quto
        lbl = QLabel('<b>Recomanded Price (P.I.): </b>', self)
        subV1.addWidget(lbl)
        subV2.addWidget(self.RPlbl)
        
        #Pricing
        lbl = QLabel('<b>Custom Price (P.I.): </b>', self)
        subV1.addWidget(lbl)
        sub = QHBoxLayout(self)
        sub.addWidget(self.pricespbx)
        lbl = QLabel('tk', self)
        sub.addWidget(lbl)
        subV2.addLayout(sub)
        
        #Amount
        lbl = QLabel('<b>Amount: </b>', self)
        subV1.addWidget(lbl)
        self.amountspbx = QSpinBox(self)
        self.amountspbx.setMinimum(1)
        self.amountspbx.setMaximum(1000)
        subV2.addWidget(self.amountspbx)
        
        #Offer Cut
        lbl = QLabel('<b>Offer Cut: </b>', self)
        subV1.addWidget(lbl)
        sub = QHBoxLayout(self)
        self.offeredt = QSpinBox(self)
        self.offeredt.setMinimum(0)
        self.offeredt.setMaximum(1000)
        sub.addWidget(self.offeredt)
        lbl = QLabel('tk', self)
        sub.addWidget(lbl)
        subV2.addLayout(sub)

        #insideLayout
        sub = QHBoxLayout(self)
        sub.addLayout(subV1)
        sub.addLayout(subV2)
        subV.addLayout(sub)
        
        
        #Button
        sub = QHBoxLayout(self)
        btn = QPushButton('Reset', self)
        btn.clicked.connect(self.resetBtnClicked)
        sub.addWidget(btn)
        #Total
        self.Tlbl = QLabel('<b>Total: </b>'+str(self.cc.result)+' tk', self)
        #button
        btn = QPushButton('Calculate', self)
        btn.clicked.connect(self.calculateBtnClicked)
        sub.addWidget(btn)
        btn = QPushButton('Add To List', self)
        btn.clicked.connect(self.addToListBtnClicked)
        sub.addWidget(btn)
        subV.addLayout(sub)
        
        #Total
        sub = QHBoxLayout(self)
        sub.addStretch(1)
        sub.addWidget(self.Tlbl)
        subV.addLayout(sub)

        #memo window
        self.mainLayout.addStretch(1)
        subH.addLayout(subV)

        #history
        subV = QVBoxLayout(self)
        sub = QHBoxLayout(self)
        self.stedt = QLineEdit('', self)
        self.stedt.setPlaceholderText('Search here')
        self.stedt.setClearButtonEnabled(True) 
        self.stedt.textChanged.connect(self.searchEng)
        sub.addWidget(self.stedt)
        subV.addLayout(sub)
        self.sellList = QListWidget(self)
        self.sellList.addItems(self.cc.pItems)
        subV.addWidget(self.sellList)
        subH.addLayout(subV) 
        self.mainLayout.addLayout(subH)

        #payment
        px = self.cc.payment
        TI = "<b>Total Income: </b>{0}<b> Personal Income: </b>{1}\
              <b> Masked Income: </b>{2}<b> Paid: </b>{3}<br/>\
              <b>Today's Income: </b>{4}<b> Today's Personal Income: </b>{6}\
              <b> Today's Masked Income: </b>{7}<br/><b>Remaning: </b>{5}"\
              .format(px[0],px[1],px[2],px[3],px[4],px[5],px[7],px[8])
        self.paymentLabel.setText(TI)
        self.mainLayout.addWidget(self.paymentLabel)

        #addnewItem
        sub = QHBoxLayout(self)
        self.nwledt = QLineEdit('New Item.Inc',self)
        sub.addWidget(self.nwledt)
        self.rbt1 = QRadioButton('.Inc', self)
        self.rbt1.setChecked(True)
        sub.addWidget(self.rbt1)
        self.rbt2 = QRadioButton('.Unc', self)
        sub.addWidget(self.rbt2)
        self.rbt3 = QRadioButton('.P', self)
        sub.addWidget(self.rbt3)
        self.rbt1.toggled.connect(self.rbtClicked)
        self.rbt2.toggled.connect(self.rbtClicked)
        self.rbt3.toggled.connect(self.rbtClicked)
        lbl = QLabel('<b>Price (P.I.): </b>', self)
        sub.addWidget(lbl)
        self.nwlspx = QSpinBox(self)
        self.nwlspx.setMaximum(10000)
        sub.addWidget(self.nwlspx)
        lbl = QLabel('tk', self)
        sub.addWidget(lbl)
        btn = QPushButton('Add Item', self)
        btn.clicked.connect(self.addItemBtnClicked)
        sub.addWidget(btn)
        self.mainLayout.addLayout(sub)
        
        #Date & Time
        self.mainLayout.addStretch(1)
        sub = QHBoxLayout(self)
        lbl = QLabel('<b>Date: </b>'+self.cc.date, self)
        sub.addWidget(lbl)
        sub.addStretch(1)
        lbl = QLabel('<b>Log in Time: </b>'+self.cc.time, self)
        sub.addWidget(lbl)
        self.mainLayout.addLayout(sub)

    #Buttons
    def resetBtnClicked(self):
        if self.T:
            self.amountspbx.setValue(1)
            self.offeredt.setValue(0)
            self.combo.clear()
            self.combo.addItems(self.cc.sellItems)
            self.pricespbx.setValue(self.cc.sellItemPrice[self.combo.currentText()])
            self.cc.result = 0
            self.result = 0
            self.Tlbl.setText('<b>Total: </b>0 tk')
        
    def calculateBtnClicked(self):
        if self.T:
            self.cc.amount = self.amountspbx.value()
            self.cc.offer = self.offeredt.value()
            self.cc.price = self.pricespbx.value()
            self.cc.Rprice()
            self.result = self.cc.result
            self.Tlbl.setText('<b>Total: </b>'+str(self.result)+' tk')
        
    def addToListBtnClicked(self):
        if self.result and self.T:
            self.cc.logos(self.combo.currentText())
            self.sellList.addItem(self.cc.logs)
            #payment
            px = self.cc.payment
            TI = "<b>Total Income: </b>{0}<b> Personal Income: </b>{1}\
              <b> Masked Income: </b>{2}<b> Paid: </b>{3}<br/>\
              <b>Today's Income: </b>{4}<b> Today's Personal Income: </b>{6}\
              <b> Today's Masked Income: </b>{7}<br/><b>Remaning: </b>{5}"\
              .format(px[0],px[1],px[2],px[3],px[4],px[5],px[7],px[8])
            self.paymentLabel.setText(TI)
        else:
            self.calculateBtnClicked()
        self.resetBtnClicked()

    #RadioButton 
    def rbtClicked(self):
        t = self.nwledt.text()
        t = t.replace('.Inc','')
        t = t.replace('.Unc','')
        t = t.replace('.P','')
        if self.rbt1.isChecked():
            t = t + '.Inc'
        if self.rbt2.isChecked():
            t = t + '.Unc'
        if self.rbt3.isChecked():
            t = t + '.P'
        self.nwledt.setText(t)
        
    def addItemBtnClicked(self):
        self.rbtClicked()
        s = self.nwledt.text()
        t = self.nwlspx.value()
        if not (s.split('.')[0] == '') and t:
            self.cc.dogos(s, t)
            self.T = self.T + 1
            self.combo.clear()
            self.combo.addItems(self.cc.sellItems)

    def searchEng(self):
        self.cc.searchBar(self.stedt.text())
        self.sellList.clear()
        self.sellList.addItems(self.cc.SearchResult)
        
    #Extra
    #combox event
    def comboOnChange(self, v):
        self.RPlbl.setText(str(self.cc.sellItemPrice[self.cc.sellItems[v]])+' tk')
        self.pricespbx.setValue(self.cc.sellItemPrice[self.cc.sellItems[v]])
        self.offeredt.setEnabled(not ('.P' in self.cc.sellItems[v] or '.Unc' in self.cc.sellItems[v]))
        self.amountspbx.setEnabled(not ('.P' in self.cc.sellItems[v]))
        
    #widget center moving code
    def center(self):
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())
