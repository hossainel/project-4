"""
Author: Md El Hossain
Website: alzestors.tk
Project: Business Tool
"""

import sys
from PyQt5.QtWidgets import QApplication as QA

from mainWindow import MainWindow as MW

if __name__ == '__main__':
    app = QA(sys.argv)
    mw = MW()
    sys.exit(app.exec_())
