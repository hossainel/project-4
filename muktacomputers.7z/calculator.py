"""
Author: Md El Hossain
Website: alzestors.tk
Project: Business Tool
"""

import math
from PyQt5.QtCore import QDate, QTime, Qt

class Calc(object):
    date = QDate.currentDate().toString(Qt.DefaultLocaleLongDate)
    time = QTime.currentTime().toString(Qt.DefaultLocaleLongDate)
    qdate = QDate.currentDate().toString(Qt.ISODate)
    sellItems = []
    pItems = []
    sellItemPrice = {'Photo Print':10, 'Document Print':10, 'Compose':30, 'Form Fill Up':100, 'Photocopy':2, 'Laminating':30}
    result = 0
    price = 0
    amount = 0
    offer = 0
    payment = [0,0,0,0,0,0]
    
    def __init__(self):
        self.loadFiles()
        
    def Rprice(self):
        self.result = self.result + (self.price * self.amount) - self.offer

    def logos(self, s):
        self.logs = s +', '+str(self.result)+'tk, '+self.qdate
        self.payLoader(self.logs+'\n')
        fob = open('files/data.txt', 'a+')
        fob.write(self.logs+'\n')
        fob.close()
        
    def dogos(self, s, t):
        f = True
        self.dogs = s+':'+str(t)+'\n'
        for i in self.sellItems:
            if s.lower().split('.')[0] == i.lower().split('.')[0]:
                f = False
                break
        if f:
            self.sellItems.append(s)
            self.sellItems.sort()
            self.sellItemPrice[s] = t
            fob = open('files/item.txt', 'a+')
            fob.write(self.dogs)
            fob.close()
        
    #Total Income:{0}Personal Income:{1}Masked Income:{2}
    #Paid:{3}Today's Income:{4}Reamining:{5}
    def payLoader(self, i):
        j,k,l = i.split(', ') #Laminating, 30tk, 2019-11-21
        if not('.P' in j):
            self.payment[0] = self.payment[0] + int(k[:-2])
        if '.Inc' in j:
            self.payment[1] = self.payment[1] + int(k[:-2])
        if '.Unc' in j:
            self.payment[2] = self.payment[2] + int(k[:-2])
        if '.P' in j:
            self.payment[3] = self.payment[3] + int(k[:-2])
        if (l[:-1] == self.qdate) and not('.P' in j):
            self.payment[4] = self.payment[4] + int(k[:-2])
        self.payment[5] = ((self.payment[1] * 55) // 100) + self.payment[2] - self.payment[3]        


    def loadFiles(self):
        fob = open('files/item.txt', 'r')
        items = fob.readlines()
        fob.close()
        for i in items:
            if ':' in i:
                j, k = i.split(':')
                self.sellItems.append(j)
                self.sellItemPrice[j] = int(k)
        self.sellItems.sort()
        with open('files/data.txt', 'r') as fob:
            items = fob.readlines()
            fob.close()

        for i in items:
            if ',' in i:
                self.payLoader(i)
                self.pItems.append(i[:-1])
